﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork18.Engine
{
    class EngineV6<TFuel> : Engine<TFuel>
    {
        public EngineV6()
        {
            version = "V6";
        }

        public override void StartsUp()
        {
            Console.WriteLine("Brrr dum dum dum");
        }
    }
}
