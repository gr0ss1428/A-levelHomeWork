﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork18.Engine
{
    abstract class Engine<TFuel>
    {
        protected string version;
        protected TFuel fuel;
        public string Version { get => version; }
        public TFuel TypeFuel { get => fuel; }
        public abstract void StartsUp();
    }
}
